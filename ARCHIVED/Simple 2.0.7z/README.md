Simple
===
This is a simple theme for WordPress.

### Version 2.0 (Updated 2018)

##### Archives
Usage: Add a post and edit the content as '[archives]'

##### Categories
Usage: Add a post and edit the content as '[categories]'

### Version 1.2 (Updated 2015)

* HTML5 & CSS3 feature
* Single column
* Elegent color
* Originized Comments List
* E-mail notify for any comments
